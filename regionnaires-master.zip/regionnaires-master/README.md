# Regionnaires

Can I just say how happy I am to have our game's name be inspired by the deadly gerophagic virus Legionnaires' disease?

I'm very happy.

# Trello Project

[Our Trello project](https://trello.com/b/woQLNOxm/regionnaires) will allow us to keep track of suggestions, completed features, etc.