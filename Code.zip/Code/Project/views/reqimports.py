from PyQt5.QtGui import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *

#from PyQt5.QtWebEngineWidgets import *
#from PyQt5.QtGui import  
#from PyQt5.QtCore import *
#from PyQt5.QtWidgets import *


from views.mainmenu import MainMenu
from views.learningzone import LearningZone
from views.splashscreen import SplashScreen
from views.quiz import Quiz
from views.freeplay import FreePlay
from views.maingamescreen import MainGameScreen
from PyQt5 import QtCore, QtWidgets, QtGui
